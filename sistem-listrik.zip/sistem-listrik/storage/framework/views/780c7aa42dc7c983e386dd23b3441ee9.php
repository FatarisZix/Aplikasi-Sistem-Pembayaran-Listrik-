

<?php $__env->startSection('title', 'Verifikasi Data'); ?>

<?php $__env->startSection('content'); ?>
<h2>Verifikasi Data Pelanggan</h2>

<div class="card">
    <?php if($dataPelanggan->count() > 0): ?>
        <table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
            <thead>
                <tr style="background: #f8f9fa;">
                    <th style="padding: 12px; border-bottom: 1px solid #ddd;">Nama</th>
                    <th style="padding: 12px; border-bottom: 1px solid #ddd;">No KWH</th>
                    <th style="padding: 12px; border-bottom: 1px solid #ddd;">Meter Awal</th>
                    <th style="padding: 12px; border-bottom: 1px solid #ddd;">Meter Akhir</th>
                    <th style="padding: 12px; border-bottom: 1px solid #ddd;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $dataPelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="padding: 12px; border-bottom: 1px solid #ddd;"><?php echo e($data->pengguna->name); ?></td>
                    <td style="padding: 12px; border-bottom: 1px solid #ddd;"><?php echo e($data->no_kwh); ?></td>
                    <td style="padding: 12px; border-bottom: 1px solid #ddd;"><?php echo e(number_format($data->meter_awal)); ?></td>
                    <td style="padding: 12px; border-bottom: 1px solid #ddd;"><?php echo e(number_format($data->meter_akhir)); ?></td>
                    <td style="padding: 12px; border-bottom: 1px solid #ddd;">
                        <a href="<?php echo e(route('admin.setujui', $data->id)); ?>" class="btn btn-success">Setujui</a>
                        <a href="<?php echo e(route('admin.tolak', $data->id)); ?>" class="btn btn-danger">Tolak</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Tidak ada data yang perlu diverifikasi.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sistem-listrik\resources\views/admin/verifikasi.blade.php ENDPATH**/ ?>