

<?php $__env->startSection('title', 'Dashboard Pengguna'); ?>

<?php $__env->startSection('content'); ?>
<h2>Dashboard Pengguna</h2>

<div class="card">
    <h3>Selamat datang, <?php echo e(Auth::user()->name); ?>!</h3>
    
    <?php if(!$dataPelanggan): ?>
        <p>Anda belum mengisi data meteran listrik.</p>
        <a href="<?php echo e(route('pengguna.input-data')); ?>" class="btn btn-primary">Input Data Meteran</a>
    <?php else: ?>
        <h4>Status Data Anda:</h4>
        <p>No KWH: <?php echo e($dataPelanggan->no_kwh); ?></p>
        <p>Meter Awal: <?php echo e(number_format($dataPelanggan->meter_awal)); ?></p>
        <p>Meter Akhir: <?php echo e(number_format($dataPelanggan->meter_akhir)); ?></p>
        <p>Status: 
            <?php if($dataPelanggan->status == 'menunggu'): ?>
                <span style="background: #fff3cd; color: #856404; padding: 4px 8px; border-radius: 4px;">Menunggu Verifikasi</span>
            <?php elseif($dataPelanggan->status == 'disetujui'): ?>
                <span style="background: #d4edda; color: #155724; padding: 4px 8px; border-radius: 4px;">Disetujui</span>
            <?php else: ?>
                <span style="background: #f8d7da; color: #721c24; padding: 4px 8px; border-radius: 4px;">Ditolak</span>
            <?php endif; ?>
        </p>
        
        <?php if($dataPelanggan->tagihan): ?>
            <h4>Tagihan Anda:</h4>
            <p>Pemakaian: <?php echo e(number_format($dataPelanggan->tagihan->pemakaian_kwh)); ?> KWH</p>
            <p>Tarif per KWH: Rp <?php echo e(number_format($dataPelanggan->tagihan->tarif_per_kwh)); ?></p>
            <p>Total Tagihan: <strong>Rp <?php echo e(number_format($dataPelanggan->tagihan->total_tagihan)); ?></strong></p>
            <a href="<?php echo e(route('pengguna.cetakStruk')); ?>" target="_blank" class="btn btn-success mt-3">Cetak Struk</a>
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sistem-listrik\resources\views/pengguna/dashboard.blade.php ENDPATH**/ ?>