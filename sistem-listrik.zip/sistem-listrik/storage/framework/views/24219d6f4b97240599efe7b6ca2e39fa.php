

<?php $__env->startSection('title', 'Dashboard Admin'); ?>

<?php $__env->startSection('content'); ?>
<h2>Dashboard Admin</h2>

<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
    <div class="card">
        <h3>Data Menunggu Verifikasi</h3>
        <p style="font-size: 2em; color: #e67e22;"><?php echo e($dataMenunggu); ?></p>
        <a href="<?php echo e(route('admin.verifikasi')); ?>" class="btn btn-primary">Lihat Detail</a>
    </div>
    
    <div class="card">
        <h3>Data Telah Disetujui</h3>
        <p style="font-size: 2em; color: #27ae60;"><?php echo e($dataDisetujui); ?></p>
        <a href="<?php echo e(route('admin.tagihan')); ?>" class="btn btn-success">Buat Tagihan</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sistem-listrik\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>