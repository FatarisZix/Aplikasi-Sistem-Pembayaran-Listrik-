

<?php $__env->startSection('title', 'Buat Tagihan'); ?>

<?php $__env->startSection('content'); ?>
<h2>Buat Tagihan Pelanggan</h2>

<div class="card">
    <?php if($dataDisetujui->count() > 0): ?>
        <table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
            <thead>
                <tr style="background: #f8f9fa;">
                    <th style="padding: 12px; border-bottom: 1px solid #ddd;">Nama</th>
                    <th style="padding: 12px; border-bottom: 1px solid #ddd;">No KWH</th>
                    <th style="padding: 12px; border-bottom: 1px solid #ddd;">Pemakaian</th>
                    <th style="padding: 12px; border-bottom: 1px solid #ddd;">Total</th>
                    <th style="padding: 12px; border-bottom: 1px solid #ddd;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $dataDisetujui; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $pemakaian = $data->meter_akhir - $data->meter_awal;
                    $total = $pemakaian * 1500;
                ?>
                <tr>
                    <td style="padding: 12px; border-bottom: 1px solid #ddd;"><?php echo e($data->pengguna->name); ?></td>
                    <td style="padding: 12px; border-bottom: 1px solid #ddd;"><?php echo e($data->no_kwh); ?></td>
                    <td style="padding: 12px; border-bottom: 1px solid #ddd;"><?php echo e(number_format($pemakaian)); ?> KWH</td>
                    <td style="padding: 12px; border-bottom: 1px solid #ddd;">Rp <?php echo e(number_format($total)); ?></td>
                    <td style="padding: 12px; border-bottom: 1px solid #ddd;">
                        <a href="<?php echo e(route('admin.buat-tagihan', $data->id)); ?>" class="btn btn-primary">Buat Tagihan</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Tidak ada data yang perlu dibuatkan tagihan.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sistem-listrik\resources\views/admin/tagihan.blade.php ENDPATH**/ ?>